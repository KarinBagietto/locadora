from models import Filme, Cliente, Locadora
from storage import Storage

DATA_DIR = "data"
FILMES_CSV = f"{DATA_DIR}/filmes.csv"
CLIENTES_CSV = f"{DATA_DIR}/clientes.csv"
EMPRÉSTIMOS_CSV = f"{DATA_DIR}/emprestimos.csv"

def main():
    storage = Storage(filmes_file=FILMES_CSV, clientes_file=CLIENTES_CSV, emprestimos_file=EMPRÉSTIMOS_CSV)
    locadora = Locadora(storage.load_filmes(), storage.load_clientes(), storage.load_emprestimos())

    while True:
        print("\n=== LOCADORA DE FILMES ===")
        print("1. Cadastrar Cliente")
        print("2. Cadastrar Filme")
        print("3. Listar Clientes")
        print("4. Listar Filmes Disponíveis")
        print("5. Alugar Filme")
        print("6. Devolver Filme")
        print("0. Sair")
        escolha = input("Escolha: ").strip()

        if escolha == "1":
            nome = input("Nome do cliente: ").strip()
            cpf = input("CPF (apenas números): ").strip()
            cliente = Cliente(nome=nome, cpf=cpf)
            success, msg = locadora.cadastrar_cliente(cliente)
            print(msg)
            if success:
                storage.save_clientes(locadora.clientes)
        elif escolha == "2":
            codigo = input("Código do filme: ").strip()
            titulo = input("Título: ").strip()
            genero = input("Gênero: ").strip()
            ano = input("Ano: ").strip()
            disponivel = True
            filme = Filme(codigo=codigo, titulo=titulo, genero=genero, ano=ano, disponivel=disponivel)
            success, msg = locadora.cadastrar_filme(filme)
            print(msg)
            if success:
                storage.save_filmes(locadora.filmes)
        elif escolha == "3":
            for c in locadora.listar_clientes():
                print(f"- {c.nome} | CPF: {c.cpf}")
        elif escolha == "4":
            term = input("Pesquisar por nome/gênero (enter para listar todos): ").strip()
            if term:
                encontrados = locadora.buscar_filmes(term)
            else:
                encontrados = [f for f in locadora.listar_filmes_disponiveis()]
            print("Ordenar por: 1) Título 2) Ano (enter para sem ordenação)")
            orden = input("Escolha: ").strip()
            if orden == "1":
                encontrados.sort(key=lambda x: x.titulo.lower())
            elif orden == "2":
                try:
                    encontrados.sort(key=lambda x: int(x.ano))
                except:
                    encontrados.sort(key=lambda x: x.ano)
            if not encontrados:
                print("Nenhum filme encontrado.")
            for f in encontrados:
                status = "Disponível" if f.disponivel else "Alugado"
                print(f"- [{f.codigo}] {f.titulo} ({f.ano}) - {f.genero} - {status}")
        elif escolha == "5":
            cpf = input("CPF do cliente: ").strip()
            codigo = input("Código do filme: ").strip()
            ok, msg = locadora.alugar_filme(cpf, codigo)
            print(msg)
            if ok:
                storage.save_filmes(locadora.filmes)
                storage.save_emprestimos(locadora.emprestimos)
        elif escolha == "6":
            cpf = input("CPF do cliente: ").strip()
            codigo = input("Código do filme: ").strip()
            ok, msg = locadora.devolver_filme(cpf, codigo)
            print(msg)
            if ok:
                storage.save_filmes(locadora.filmes)
                storage.save_emprestimos(locadora.emprestimos)
        elif escolha == "0":
            print("Saindo...")
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()