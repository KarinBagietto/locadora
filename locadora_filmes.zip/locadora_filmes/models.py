import csv
from dataclasses import dataclass

@dataclass
class Filme:
    codigo: str
    titulo: str
    genero: str
    ano: str
    disponivel: bool = True

    def to_dict(self):
        return {
            "codigo": self.codigo,
            "titulo": self.titulo,
            "genero": self.genero,
            "ano": self.ano,
            "disponivel": str(self.disponivel)
        }

    @staticmethod
    def from_dict(d):
        return Filme(codigo=d["codigo"], titulo=d["titulo"], genero=d["genero"], ano=d["ano"], disponivel=(d.get("disponivel","True") in ("True","true","1")))

@dataclass
class Cliente:
    nome: str
    cpf: str

    def to_dict(self):
        return {"nome": self.nome, "cpf": self.cpf}

    @staticmethod
    def from_dict(d):
        return Cliente(nome=d["nome"], cpf=d["cpf"])

class Locadora:
    def __init__(self, filmes=None, clientes=None, emprestimos=None):
        self.filmes = filmes or []
        self.clientes = clientes or []
        # emprestimos: dict CPF -> list of codigo_filme
        self.emprestimos = emprestimos or {}

    def cadastrar_filme(self, filme: Filme):
        if any(f.codigo == filme.codigo for f in self.filmes):
            return False, f"Já existe filme com código {filme.codigo}."
        self.filmes.append(filme)
        return True, "Filme cadastrado com sucesso."

    def cadastrar_cliente(self, cliente: Cliente):
        if any(c.cpf == cliente.cpf for c in self.clientes):
            return False, f"CPF {cliente.cpf} já cadastrado."
        self.clientes.append(cliente)
        return True, "Cliente cadastrado com sucesso."

    def listar_filmes_disponiveis(self):
        return [f for f in self.filmes if f.disponivel]

    def listar_clientes(self):
        return self.clientes

    def alugar_filme(self, cpf_cliente, codigo_filme):
        cliente = next((c for c in self.clientes if c.cpf == cpf_cliente), None)
        if not cliente:
            return False, "Cliente não encontrado."
        filme = next((f for f in self.filmes if f.codigo == codigo_filme), None)
        if not filme:
            return False, "Filme não encontrado."
        if not filme.disponivel:
            return False, "Filme não está disponível."
        filme.disponivel = False
        self.emprestimos.setdefault(cpf_cliente, []).append(codigo_filme)
        return True, "Filme alugado com sucesso."

    def devolver_filme(self, cpf_cliente, codigo_filme):
        if cpf_cliente not in self.emprestimos or codigo_filme not in self.emprestimos.get(cpf_cliente, []):
            return False, "Empréstimo não encontrado para esse cliente e filme."
        filme = next((f for f in self.filmes if f.codigo == codigo_filme), None)
        if not filme:
            return False, "Filme não encontrado."
        filme.disponivel = True
        self.emprestimos[cpf_cliente].remove(codigo_filme)
        if not self.emprestimos[cpf_cliente]:
            del self.emprestimos[cpf_cliente]
        return True, "Filme devolvido com sucesso."

    def buscar_filmes(self, termo):
        termo = termo.lower()
        return [f for f in self.filmes if termo in f.titulo.lower() or termo in f.genero.lower()]