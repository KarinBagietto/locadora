import csv, os
from models import Filme, Cliente

class Storage:
    def __init__(self, filmes_file="data/filmes.csv", clientes_file="data/clientes.csv", emprestimos_file="data/emprestimos.csv"):
        self.filmes_file = filmes_file
        self.clientes_file = clientes_file
        self.emprestimos_file = emprestimos_file
        os.makedirs(os.path.dirname(self.filmes_file), exist_ok=True)

    def load_filmes(self):
        filmes = []
        if not os.path.exists(self.filmes_file):
            return filmes
        with open(self.filmes_file, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                filmes.append(Filme.from_dict(row))
        return filmes

    def save_filmes(self, filmes):
        with open(self.filmes_file, 'w', newline='', encoding='utf-8') as f:
            fieldnames = ["codigo","titulo","genero","ano","disponivel"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for film in filmes:
                writer.writerow(film.to_dict())

    def load_clientes(self):
        clientes = []
        if not os.path.exists(self.clientes_file):
            return clientes
        with open(self.clientes_file, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                clientes.append(Cliente.from_dict(row))
        return clientes

    def save_clientes(self, clientes):
        with open(self.clientes_file, 'w', newline='', encoding='utf-8') as f:
            fieldnames = ["nome","cpf"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for c in clientes:
                writer.writerow(c.to_dict())

    def load_emprestimos(self):
        emprestimos = {}
        if not os.path.exists(self.emprestimos_file):
            return emprestimos
        with open(self.emprestimos_file, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                cpf = row["cpf"]
                codigo = row["codigo_filme"]
                emprestimos.setdefault(cpf, []).append(codigo)
        return emprestimos

    def save_emprestimos(self, emprestimos):
        with open(self.emprestimos_file, 'w', newline='', encoding='utf-8') as f:
            fieldnames = ["cpf","codigo_filme"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for cpf, codigos in emprestimos.items():
                for c in codigos:
                    writer.writerow({"cpf":cpf, "codigo_filme":c})