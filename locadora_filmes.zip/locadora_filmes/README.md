# Locadora de Filmes (Python)

Projeto simples de sistema de locadora de filmes (linha de comando) em Python.

Funcionalidades:
- Cadastrar clientes (evita CPF duplicado)
- Cadastrar filmes
- Listar clientes
- Listar filmes disponíveis (filtro por nome/gênero e ordenação por título/ano)
- Alugar filme
- Devolver filme
- Persistência em CSV (data/filmes.csv, data/clientes.csv, data/emprestimos.csv)

Como usar:
1. Abra em VSCode ou terminal.
2. Rode: `python app.py`
3. Siga o menu interativo.

Arquivos gerados/esperados na pasta `data/`:
- filmes.csv
- clientes.csv
- emprestimos.csv